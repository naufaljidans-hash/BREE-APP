<?php

namespace Tests\Feature\Auth;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Fortify\Features;
use Tests\TestCase;

class RegistrationTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->skipUnlessFortifyHas(Features::registration());
    }

    public function test_registration_screen_can_be_rendered()
    {
        $response = $this->get(route('register'));

        $response->assertOk();
    }

    public function test_new_users_can_register()
    {
        $response = $this->post(route('register.store'), [
            'name' => 'Test User',
            'email' => 'test@example.com',
            'password' => 'password',
        ]);

        $this->assertAuthenticated();
        // A new owner opens the books first (onboarding wizard).
        $response->assertRedirect(route('onboarding.show', absolute: false));
    }

    public function test_the_password_needs_eight_characters_and_no_repeat_field(): void
    {
        $this->post(route('register.store'), ['name' => 'Rina', 'email' => 'rina@example.com', 'password' => 'pendek7'])
            ->assertSessionHasErrors('password');

        $this->assertGuest();
    }
}
