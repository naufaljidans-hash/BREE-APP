<?php

use App\Http\Middleware\HandleAppearance;
use App\Http\Middleware\HandleInertiaRequests;
use App\Http\Middleware\RequirePasswordIfSet;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Middleware\AddLinkHeadersForPreloadedAssets;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Symfony\Component\HttpFoundation\Response;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->encryptCookies(except: ['appearance', 'sidebar_state']);
        // GOWA and DOKU sign their webhooks with HMAC instead (GowaWebhookController, DokuWebhookController).
        $middleware->validateCsrfTokens(except: ['webhooks/gowa', 'webhooks/doku']);
        // In Coolify, TLS ends at the reverse proxy; without this the app builds http:// links.
        $middleware->trustProxies(at: '*');
        // Fortify's two-factor routes use the alias too.
        $middleware->alias(['password.confirm' => RequirePasswordIfSet::class]);

        $middleware->web(append: [
            HandleAppearance::class,
            HandleInertiaRequests::class,
            AddLinkHeadersForPreloadedAssets::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson(),
        );

        // With debug on the framework's own page explains the error; JSON callers read the message.
        $exceptions->respond(function (Response $response, Throwable $exception, Request $request) {
            if (config('app.debug') || $request->expectsJson() || ! in_array($response->getStatusCode(), [403, 404, 419, 500, 503], true)) {
                return $response;
            }

            return Inertia::render('errors/show', ['status' => $response->getStatusCode()])
                ->toResponse($request)
                ->setStatusCode($response->getStatusCode());
        });
    })->create();
