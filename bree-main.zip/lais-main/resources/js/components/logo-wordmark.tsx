import type { HTMLAttributes } from 'react';
import { cn } from '@/lib/utils';

/** Bree wordmark paired with the supplied brand mark. */
export function LogoWordmark({
    className,
    title = 'Bree',
    ...props
}: HTMLAttributes<HTMLSpanElement> & { title?: string }) {
    return (
        <span
            role="img"
            aria-label={title}
            className={cn('inline-flex items-center gap-2 text-foreground', className)}
            {...props}
        >
            <img src="/images/bree-mark.png" alt="" className="h-7 w-7 shrink-0 object-contain" />
            <span className="font-bold tracking-[0.16em]">BREE</span>
        </span>
    );
}
