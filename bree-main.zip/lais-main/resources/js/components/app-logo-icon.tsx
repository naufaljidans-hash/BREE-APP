import type { ImgHTMLAttributes } from 'react';

/** Bree brand mark used in compact application navigation. */
export default function AppLogoIcon(props: ImgHTMLAttributes<HTMLImageElement>) {
    return <img src="/images/bree-mark.png" alt={props.alt ?? ''} {...props} />;
}
